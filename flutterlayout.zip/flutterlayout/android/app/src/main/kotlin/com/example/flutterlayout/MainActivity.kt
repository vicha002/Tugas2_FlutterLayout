package com.example.flutterlayout

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
